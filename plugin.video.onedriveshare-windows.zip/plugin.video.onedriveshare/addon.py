"""
plugin.video.onedriveshare — main entry point
Crash-safe: every import and operation is wrapped so Kodi always gets
endOfDirectory() and the log captures what went wrong.
"""

import sys, os, json, time, traceback, random

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON     = xbmcaddon.Addon()
ADDON_ID  = ADDON.getAddonInfo('id')
ADDON_VER = ADDON.getAddonInfo('version')
HANDLE    = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL  = sys.argv[0] if sys.argv else ''

# ── Diagnostic log ──────────────────────────────────────────────────────────
_LOG_PATH      = os.path.join(xbmcvfs.translatePath('special://logpath'), 'onedriveshare_debug.log')
_MAX_LOG_BYTES = 256 * 1024

def dlog(level, msg):
    ts   = time.strftime('%Y-%m-%d %H:%M:%S')
    line = '[{}] [{}] [{}] {}\n'.format(ts, ADDON_ID, level.upper(), msg)
    try:
        if os.path.exists(_LOG_PATH) and os.path.getsize(_LOG_PATH) > _MAX_LOG_BYTES:
            with open(_LOG_PATH, 'rb') as f:
                f.seek(-128 * 1024, 2); tail = f.read()
            with open(_LOG_PATH, 'wb') as f:
                f.write(tail)
        with open(_LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass
    kodi_lvl = {'debug': xbmc.LOGDEBUG, 'info': xbmc.LOGINFO,
                'warn': xbmc.LOGWARNING, 'error': xbmc.LOGERROR}.get(level.lower(), xbmc.LOGINFO)
    xbmc.log(line.strip(), kodi_lvl)

def dlog_exc(ctx, exc):
    dlog('error', '{}: {} — {}'.format(ctx, type(exc).__name__, exc))
    dlog('error', 'Traceback:\n' + traceback.format_exc())

dlog('info', '=== addon start v{} args={} ==='.format(ADDON_VER, sys.argv))

# ── Parse args ───────────────────────────────────────────────────────────────
try:
    from urllib.parse import parse_qsl, urlencode, unquote
    ARGS = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
    dlog('debug', 'ARGS={}'.format(ARGS))
except Exception as e:
    dlog_exc('arg parse', e); ARGS = {}

# ── Lib imports ──────────────────────────────────────────────────────────────
_import_ok = True
try:
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))
    from config     import get_credentials
    from auth       import get_access_token
    from sharepoint import get_share_items, find_subtitle_for_video
    dlog('info', 'lib imports OK')
except Exception as e:
    _import_ok = False; dlog_exc('lib import', e)

def build_url(**kw):
    return '{}?{}'.format(BASE_URL, urlencode(kw))

# ── PIN relay (file-based, same device) ─────────────────────────────────────
_PIN_DIR = xbmcvfs.translatePath('special://userdata/addon_data/{}/pins/'.format(ADDON_ID))

def _ensure_pin_dir():
    try:
        if not os.path.isdir(_PIN_DIR): os.makedirs(_PIN_DIR)
    except Exception: pass

def generate_pin():
    _ensure_pin_dir()
    pin  = '{:04d}'.format(random.randint(1000, 9999))
    slot = os.path.join(_PIN_DIR, pin + '.json')
    try:
        with open(slot, 'w') as f: json.dump({'ts': time.time(), 'url': ''}, f)
    except Exception as e: dlog_exc('generate_pin', e)
    dlog('info', 'PIN generated: {}'.format(pin))
    return pin

def poll_pin(pin):
    slot = os.path.join(_PIN_DIR, pin + '.json')
    try:
        if os.path.exists(slot):
            with open(slot) as f: data = json.load(f)
            url = data.get('url', '').strip()
            if url:
                dlog('info', 'PIN {} claimed'.format(pin))
                os.remove(slot)
                return url
    except Exception as e: dlog_exc('poll_pin', e)
    return ''

def receive_pin(pin, url):
    _ensure_pin_dir()
    slot = os.path.join(_PIN_DIR, pin + '.json')
    try:
        with open(slot, 'w') as f: json.dump({'ts': time.time(), 'url': url}, f)
        dlog('info', 'PIN {} slot written'.format(pin)); return True
    except Exception as e: dlog_exc('receive_pin', e); return False

# ── Handlers ──────────────────────────────────────────────────────────────────

def show_log_viewer():
    try:
        if not os.path.exists(_LOG_PATH):
            xbmcgui.Dialog().ok('Debug Log', 'No log yet.\nPath: ' + _LOG_PATH)
        else:
            with open(_LOG_PATH, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            last = lines[-200:]
            xbmcgui.Dialog().textviewer(
                'OneDrive Share — Debug Log (last {} lines)'.format(len(last)),
                ''.join(last)
            )
    except Exception as e: dlog_exc('log_viewer', e); xbmcgui.Dialog().ok('Log Error', str(e))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

def handle_pair_start():
    pin       = generate_pin()
    setup_url = 'https://ghemed.github.io/kodi-setup/'
    dialog    = xbmcgui.DialogProgress()
    dialog.create(
        'OneDrive Share — Pair',
        'Open on your phone:\n  {}\n\nEnter PIN:  [B]{}[/B]\n\nWaiting for phone...'.format(setup_url, pin)
    )
    dlog('info', 'Pair waiting PIN={}'.format(pin))
    deadline = time.time() + 120
    while time.time() < deadline:
        if dialog.iscanceled(): dlog('info', 'pair cancelled'); break
        remaining = int(deadline - time.time())
        dialog.update(
            int((1 - remaining/120)*100),
            'Open on your phone:\n  {}\n\nEnter PIN:  [B]{}[/B]\n\nWaiting... ({}s)'.format(setup_url, pin, remaining)
        )
        url = poll_pin(pin)
        if url:
            dialog.close()
            ADDON.setSetting('share_url', url)
            dlog('info', 'Pair success, url saved')
            xbmcgui.Dialog().notification('OneDrive Share', 'Setup complete! Loading videos…', xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.sleep(400)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
            xbmc.executebuiltin('Container.Refresh')
            return
        xbmc.sleep(3000)
    dialog.close()
    xbmcgui.Dialog().ok('OneDrive Share', 'Setup timed out. Try again.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

def handle_setpin():
    pin = ARGS.get('pin', '').strip()
    url = unquote(ARGS.get('url', '')).strip()
    dlog('info', 'setpin pin={} url_len={}'.format(pin, len(url)))
    if pin and url:
        ok  = receive_pin(pin, url)
        msg = 'URL received! TV is loading your videos.' if ok else 'Could not save PIN slot.'
        xbmcgui.Dialog().notification('OneDrive Share', msg, xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok('OneDrive Share', 'Missing PIN or URL.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def handle_seturl():
    share_url = unquote(ARGS.get('url', '')).strip()
    dlog('info', 'seturl url_len={}'.format(len(share_url)))
    if share_url:
        ADDON.setSetting('share_url', share_url)
        xbmcgui.Dialog().notification('OneDrive Share', 'Share URL saved! Loading videos…', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.onedriveshare/,return)')
    else:
        xbmcgui.Dialog().ok('OneDrive Share', 'No URL received.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def list_folder(subfolder_id=None, drive_id=None):
    if not _import_ok:
        xbmcgui.Dialog().ok('OneDrive Share', 'Library import failed.\nCheck the debug log.')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    xbmcplugin.setContent(HANDLE, 'videos')
    share_url = ADDON.getSetting('share_url').strip()

    if not share_url:
        for label, act in [('[Pair with phone — enter PIN]','pair'), ('[View debug log]','log')]:
            li = xbmcgui.ListItem(label=label); li.setArt({'icon':'DefaultAddonProgram.png'})
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action=act), li, isFolder=True)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True); return

    dlog('info', 'list_folder sub={} drive={}'.format(subfolder_id, drive_id))
    try:
        creds = get_credentials(); dlog('debug', 'creds OK')
        token = get_access_token(creds['tenant_id'], creds['client_id'], creds['client_secret'])
        dlog('debug', 'token OK')
        items, resolved_drive_id = get_share_items(share_url, token, subfolder_id=subfolder_id, drive_id=drive_id)
        dlog('info', 'items count={}'.format(len(items)))
    except Exception as e:
        dlog_exc('list_folder', e)
        if xbmcgui.Dialog().yesno('OneDrive Share — Error', str(e) + '\n\nReset and reconfigure?'):
            ADDON.setSetting('share_url', '')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    if not items:
        xbmcgui.Dialog().notification('OneDrive Share', 'No videos found.', xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True); return

    for item in items:
        if item['type'] == 'folder':
            li = xbmcgui.ListItem(label='[{}]'.format(item['name'])); li.setArt({'icon':'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='folder', item_id=item['item_id'], drive_id=resolved_drive_id), li, isFolder=True)
        elif item['type'] == 'video':
            title = item['name'].rsplit('.', 1)[0]
            li    = xbmcgui.ListItem(label=title); li.setArt({'icon':'DefaultVideo.png'})
            li.setInfo('video', {'title': title}); li.setProperty('IsPlayable', 'true')
            sub = find_subtitle_for_video(items, item['name'])
            xbmcplugin.addDirectoryItem(HANDLE, build_url(action='play', url=item['url'], subtitle=sub or ''), li, isFolder=False)

    for label, act in [('[⚙ Re-pair / Change URL]', 'pair'), ('[🔍 View debug log]', 'log')]:
        li = xbmcgui.ListItem(label=label); li.setArt({'icon':'DefaultAddonProgram.png'})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=act), li, isFolder=True)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def play_video(stream_url, subtitle_url=None):
    dlog('info', 'play url={}'.format(stream_url[:80]))
    li = xbmcgui.ListItem(path=stream_url)
    if subtitle_url and ADDON.getSetting('show_subtitles') == 'true':
        li.setSubtitles([subtitle_url])
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)

# ── Router ────────────────────────────────────────────────────────────────────
try:
    action = ARGS.get('action')
    dlog('debug', 'route action={}'.format(action))
    if   action == 'seturl':  handle_seturl()
    elif action == 'setpin':  handle_setpin()
    elif action == 'pair':    handle_pair_start()
    elif action == 'log':     show_log_viewer()
    elif action == 'noop':    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == 'folder':  list_folder(subfolder_id=ARGS.get('item_id'), drive_id=ARGS.get('drive_id'))
    elif action == 'play':    play_video(ARGS.get('url', ''), ARGS.get('subtitle') or None)
    elif action is None:      list_folder()
    else:
        dlog('warn', 'unknown action={}'.format(action))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
except Exception as e:
    dlog_exc('router', e)
    try:
        xbmcgui.Dialog().ok('OneDrive Share — Crash', str(e) + '\n\nCheck debug log.')
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    except Exception: pass
