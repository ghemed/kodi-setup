import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qsl, urlencode, unquote

from config import get_credentials
from auth import get_access_token
from sharepoint import get_share_items, find_subtitle_for_video

ADDON    = xbmcaddon.Addon()
HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
ARGS     = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}


def build_url(**kw):
    return '{}?{}'.format(BASE_URL, urlencode(kw))


# ---------------------------------------------------------------------------
# seturl — called via deep link from the GitHub Pages setup page
# plugin://plugin.video.onedriveshare/?action=seturl&url=ENCODED_SHARE_URL
# ---------------------------------------------------------------------------

def handle_seturl():
    raw = ARGS.get('url', '')
    share_url = unquote(raw).strip()
    if share_url:
        ADDON.setSetting('share_url', share_url)
        xbmcgui.Dialog().notification(
            'OneDrive Share',
            'Share URL saved! Loading your videos...',
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        xbmc.executebuiltin('Container.Refresh')
        # Navigate into the addon to show videos immediately
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.onedriveshare/,return)')
    else:
        xbmcgui.Dialog().ok('OneDrive Share', 'No URL received. Please try the setup link again.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


# ---------------------------------------------------------------------------
# Directory listing
# ---------------------------------------------------------------------------

def list_folder(subfolder_id=None, drive_id=None):
    xbmcplugin.setContent(HANDLE, 'videos')
    share_url = ADDON.getSetting('share_url').strip()

    try:
        creds = get_credentials()
        token = get_access_token(creds['tenant_id'], creds['client_id'], creds['client_secret'])
        items, resolved_drive_id = get_share_items(
            share_url, token,
            subfolder_id=subfolder_id,
            drive_id=drive_id,
        )
    except Exception as e:
        fix = xbmcgui.Dialog().yesno(
            'OneDrive Share - Error',
            '{}\n\nWould you like to reset and re-enter your share URL?'.format(str(e))
        )
        if fix:
            ADDON.setSetting('share_url', '')
            xbmcgui.Dialog().ok(
                'OneDrive Share',
                'Share URL cleared.\n\nOpen the setup link sent to you to reconfigure.'
            )
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if not items:
        xbmcgui.Dialog().notification('OneDrive Share', 'No videos found.',
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        if item['type'] == 'folder':
            li = xbmcgui.ListItem(label='[{}]'.format(item['name']))
            li.setArt({'icon': 'DefaultFolder.png'})
            url = build_url(action='folder', item_id=item['item_id'], drive_id=resolved_drive_id)
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
        elif item['type'] == 'video':
            title = item['name'].rsplit('.', 1)[0]
            li    = xbmcgui.ListItem(label=title)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': title})
            li.setProperty('IsPlayable', 'true')
            sub = find_subtitle_for_video(items, item['name'])
            url = build_url(action='play', url=item['url'], subtitle=sub or '')
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    li = xbmcgui.ListItem(label='[Change Share URL]')
    li.setArt({'icon': 'DefaultAddonProgram.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(action='configure'), li, isFolder=True)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


# ---------------------------------------------------------------------------
# Playback
# ---------------------------------------------------------------------------

def play_video(stream_url, subtitle_url=None):
    li = xbmcgui.ListItem(path=stream_url)
    if subtitle_url and ADDON.getSetting('show_subtitles') == 'true':
        li.setSubtitles([subtitle_url])
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

action = ARGS.get('action')

if action == 'seturl':
    # Called from the GitHub Pages setup link
    handle_seturl()

elif action is None:
    share_url = ADDON.getSetting('share_url').strip()
    if not share_url:
        xbmcgui.Dialog().ok(
            'OneDrive Share',
            'No share URL configured yet.\n\nOpen the setup link sent to you by the person who invited you.'
        )
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    else:
        list_folder()

elif action == 'folder':
    list_folder(subfolder_id=ARGS.get('item_id'), drive_id=ARGS.get('drive_id'))

elif action == 'play':
    play_video(ARGS.get('url', ''), ARGS.get('subtitle') or None)

elif action == 'configure':
    xbmcgui.Dialog().ok(
        'OneDrive Share',
        'To change your share URL, open the setup link sent to you again.\n\n'
        'Or ask the person who invited you to send a new link.'
    )
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

else:
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
