import json
import time
from urllib.request import urlopen, Request
from urllib.error import HTTPError

GIST_URL = 'https://gist.githubusercontent.com/ghemed/8b3d726b7ddca3f4304ec5f64fad4c06/raw/config.json'

_cache = {'data': None, 'fetched_at': 0}
CACHE_TTL = 300


def get_credentials():
    now = time.time()
    if _cache['data'] and now - _cache['fetched_at'] < CACHE_TTL:
        return _cache['data']
    req = Request(GIST_URL, headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'})
    try:
        with urlopen(req, timeout=15) as r:
            data = json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        raise RuntimeError('Could not fetch credentials (HTTP {}).'.format(e.code))
    except Exception as e:
        raise RuntimeError('Could not fetch credentials: {}'.format(str(e)))
    missing = [k for k in ('tenant_id', 'client_id', 'client_secret') if not data.get(k)]
    if missing:
        raise RuntimeError('Credentials missing: {}'.format(', '.join(missing)))
    _cache['data'] = data
    _cache['fetched_at'] = now
    return data
