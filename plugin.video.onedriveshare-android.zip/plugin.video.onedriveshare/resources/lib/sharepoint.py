import base64
import json
from urllib.request import urlopen, Request
from urllib.parse import quote
from urllib.error import HTTPError

VIDEO_EXTENSIONS    = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.m4v', '.mpg', '.mpeg', '.ts', '.m2ts', '.flv', '.webm')
SUBTITLE_EXTENSIONS = ('.srt', '.sub', '.ass', '.ssa', '.vtt')


def _encode_share_url(share_url):
    encoded = base64.b64encode(share_url.encode('utf-8')).decode('utf-8')
    return 'u!' + encoded.rstrip('=').replace('/', '_').replace('+', '-')


def _fetch_json(url, token):
    req = Request(url, headers={
        'Authorization': 'Bearer {}'.format(token),
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0',
    })
    try:
        with urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        raise RuntimeError('Graph API error (HTTP {}): {}'.format(e.code, e.read().decode()[:300]))


def resolve_share_to_drive(share_url, token):
    token_id = _encode_share_url(share_url)
    data = _fetch_json('https://graph.microsoft.com/v1.0/shares/{}/driveItem'.format(token_id), token)
    drive_id = (data.get('parentReference', {}).get('driveId') or
                data.get('remoteItem', {}).get('parentReference', {}).get('driveId'))
    item_id  = data.get('id') or data.get('remoteItem', {}).get('id')
    if not drive_id or not item_id:
        raise RuntimeError('Could not resolve share link to a drive item.')
    return drive_id, item_id


def get_share_items(share_url, token, subfolder_id=None, drive_id=None):
    if subfolder_id and drive_id:
        url = 'https://graph.microsoft.com/v1.0/drives/{}/items/{}/children?$top=500'.format(drive_id, subfolder_id)
    else:
        drive_id, root_id = resolve_share_to_drive(share_url, token)
        url = 'https://graph.microsoft.com/v1.0/drives/{}/items/{}/children?$top=500'.format(drive_id, root_id)

    raw_items = _fetch_json(url, token).get('value', [])
    items = []
    for item in raw_items:
        name = item.get('name', '')
        if not name:
            continue
        ext = ('.' + name.rsplit('.', 1)[-1].lower()) if '.' in name else ''
        download_url = item.get('@microsoft.graph.downloadUrl', '')
        if 'folder' in item:
            items.append({'name': name, 'type': 'folder', 'url': '', 'item_id': item.get('id', ''), 'drive_id': drive_id})
        elif ext in VIDEO_EXTENSIONS:
            items.append({'name': name, 'type': 'video', 'url': download_url, 'item_id': item.get('id', ''), 'drive_id': drive_id})
        elif ext in SUBTITLE_EXTENSIONS:
            items.append({'name': name, 'type': 'subtitle', 'url': download_url, 'item_id': item.get('id', ''), 'drive_id': drive_id})

    items.sort(key=lambda x: (0 if x['type'] == 'folder' else 1 if x['type'] == 'video' else 2, x['name'].lower()))
    return items, drive_id


def find_subtitle_for_video(items, video_name):
    base = video_name.rsplit('.', 1)[0].lower()
    for item in items:
        if item['type'] == 'subtitle' and item['name'].rsplit('.', 1)[0].lower() == base:
            return item['url']
    return None
