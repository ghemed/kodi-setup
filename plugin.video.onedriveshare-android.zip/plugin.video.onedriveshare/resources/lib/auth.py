import json
import time
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from urllib.error import HTTPError

_token_cache = {}


def get_access_token(tenant_id, client_id, client_secret):
    key = '{}:{}'.format(tenant_id, client_id)
    cached = _token_cache.get(key)
    if cached and cached['expires_at'] > time.time() + 60:
        return cached['token']
    url = 'https://login.microsoftonline.com/{}/oauth2/v2.0/token'.format(tenant_id)
    body = urlencode({
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'https://graph.microsoft.com/.default',
    }).encode('utf-8')
    req = Request(url, data=body, headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0',
    })
    try:
        with urlopen(req, timeout=15) as r:
            data = json.loads(r.read().decode('utf-8'))
    except HTTPError as e:
        raise RuntimeError('Auth failed (HTTP {}): {}'.format(e.code, e.read().decode()[:200]))
    token = data.get('access_token')
    if not token:
        raise RuntimeError('No access_token returned. Check credentials.')
    _token_cache[key] = {'token': token, 'expires_at': time.time() + int(data.get('expires_in', 3600))}
    return token
